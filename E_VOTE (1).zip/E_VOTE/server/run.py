# mysqldump -u root -p oldage > schema.sql
from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from flaskext.mysql import MySQL
import os
import random,string
from datetime import datetime
from flask_mail import Mail, Message
app= Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

# database cofiguration
mysql = MySQL()
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'root'
app.config['MYSQL_DATABASE_DB'] = 'e_vote'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
# app.config["UPLOADS"] = '/Users/tequevia/Desktop/oldage/uploads'
mysql.init_app(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'evoteihrdkumbla@gmail.com'
app.config['MAIL_PASSWORD'] = 'evote2021'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)
# mail configuration



@app.route('/')
def index():
    return render_template('index.html')

# @app.route('/login',methods=['GET','POST'])
# def login():
#     if request.method=="GET":
#         return render_template('login.html')
#     if request.method=="POST":
#         print('login logic')

#         username=request.form['username']
#         password=request.form['password']

#         query="select * from login where username='"+username+"' and password='"+password+"'"
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         cursor.execute(query)
#         account=cursor.fetchone()
#         if account:
#             print(account[3])
#             session['rid']=account[4]
#             session['lid']=account[0]
#             session['type']=account[3]
#             if account[3]=="admin":
#                 return render_template('admin.html')
#             if account[3]=="student":
#                 return render_template('voters.html')
#             if account[3]=="candidate":
#                 return render_template('candidate.html')
#             print('avail')
#         else:
#             print('un avail')
#         print(query)
#         return "ok"
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=="GET":
        return render_template('login.html')
    if request.method=="POST":
        data=request.form
        conn= mysql.connect()
        cursor=conn.cursor()
        query="select * from login where username=%s and password =%s"
        cursor.execute(query,(data['username'],data['password']))
        conn.commit()
        account =cursor.fetchone()
        if account:
            print(account)
            session['loggedin']=True 
            session['rid']=account[4]
            session['lid']=account[0]
            session['type']=account[3]
            if account[3]=="admin":
                return render_template('admin.html')
            if account[3]=="student":
                return render_template('voters.html')
            if account[3]=="candidate":
                return render_template('candidate.html')
            print('avail')
        else:
        #     print('un avail')
        # print(query)
            return render_template('login.html')

@app.route('/logout',methods=['GET'])
def logout():
    print(session['loggedin'])
    if session['loggedin']:
        session['loggedin']=False
        session.pop(id,None)
        session.pop('username',None)
        return redirect(url_for('index'))
    else:
        print("loging first")  
        return "something went wrong"  

    
@app.route('/candidate')
def candidate():
    if session['type']=="candidate":
        return render_template('candidate.html')
    elif session['type']=="student":
        return render_template('voters.html')
    elif session['type']=="admin":
        return render_template('admin.html')
    else:
        return render_template('index.html')


@app.route('/voters')
def voters():
    return render_template('voters.html')


@app.route('/notifications')
def notifications():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select * from notifications")
        row=cursor.fetchall() 
        print(row)
        return render_template('notifications.html',row=row)


# @app.route('/edit/<string:id>')
# def postnomination(id):
#    if request.method == 'GET':
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         cursor.execute("select * from registration where rid=%s")
#         row=cursor.fetchone()
#         conn.close()
#         cursor.close()
        # return render_template('postnomination.html',row=row) 
 
# @app.route('/postnomination')
# def postnomination():    
    # if request.method == 'GET':
    #     return render_template("postnomination.html")
    # if request.method=='POST':
    #     data = request.form
    #     # print(data)
    #     conn = mysql.connect()
    #     cursor = conn.cursor()
    #     query = "insert into nomination(post,status,reg_id) values (%s,%s,%s)"
    #     cursor.execute(query, (data['post'],'pending',reg_id))
    #     conn.commit()
    #     conn.close()
    #     cursor.close()
        # return render_template('postnomination.html')


   
@app.route('/postnominationedit',methods=['GET','POST'])
def postnominationedit():  
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        print(session['rid'])
        # cursor.execute("select * from registration where rid="+str(session['rid']))
        cursor.execute("select * from registration where rid="+str(session['rid']))
        rows=cursor.fetchone()
        conn.close()
        cursor.close()
        print(rows)
        dt={"data":rows,"out":[]}
        return render_template('postnomination.html',data=dt) 
    if request.method == 'POST':
        data = request.form
        conn = mysql.connect()
        cursor = conn.cursor()
        print(session['rid'])
        query = "INSERT INTO nomination(post,stauts,rid) VALUES(%s,%s,%s)"
        cursor.execute(query,(data['post'],'pending',session['rid']))
        conn.commit()
        conn.close()
        cursor.close()
        return render_template('postnomination.html') 

@app.route('/postnomination',methods=['GET','POST'])
def postnomination():
    if request.method == 'GET': 
        to_time= datetime(2021, 5, 21, 6, 54, 23, 629225)
        current_time = datetime.now()
        if current_time > to_time:
            return render_template('nomtime.html')
        else:    
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute("select * from posts")
            row=cursor.fetchall()
            conn.close()
            cursor.close()
            print(row)
            data='minor'
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute("select * from registration where rid="+str(session['rid']))
            rows=cursor.fetchone()
            conn.close()
            cursor.close()
            conn = mysql.connect()
            cursor = conn.cursor()
            print(data)
            cursor.execute("select * from posts where type=%s",data)
            row=cursor.fetchall()
            # print(row)
            dt={"data":rows,"out":row}
            return render_template('postnomination.html',row=row,data=dt) 

    if request.method=="POST":
        data=request.form['type']
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select * from registration where rid="+str(session['rid']))
        rows=cursor.fetchone()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        print(data)
        cursor.execute("select * from posts where type=%s",data)
        row=cursor.fetchall()
        # print(row)
        dt={"data":rows,"out":row}
        # print(dt)
        return render_template('postnomination.html',data=dt)



@app.route('/new-nomination',methods=['GET','POST'])
def newnomination():
        if request.method == 'POST': 
            data = request.form
            conn = mysql.connect()
            cursor = conn.cursor()
            query = "INSERT INTO nomination(post,status,reg_id) VALUES(%s,%s,%s)"
            cursor.execute(query,(data['post'],'pending',session['rid']))
            conn.commit()
            conn.close()
            cursor.close()
            return redirect(url_for('voters'))



@app.route('/postmanifesto',methods=['GET','POST'])
def postmanifesto():
    if request.method == 'GET':  
        return render_template("postmanifesto.html")
    if request.method=='POST':
        data=request.form
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.rid,nomination.nomination_id,nomination.status from nomination,registration where status='Accept' and nomination.reg_id="+str(session['rid']))
        rows=cursor.fetchone()
        # print(rows[0])
        # print(rows[1])
        # print(rows[2])
        # conn.close()
        # cursor.close()
        query = "insert into manifesto(manifesto,nm_id) values (%s,%s)"
        cursor.execute(query, (data['manifesto'],rows[1]))
        conn.commit()
        conn.close()
        return redirect(url_for('postmanifesto'))

       



        


# @app.route('/editmanifesto')
# def editmanifesto():
#     return render_template('editmanifesto.html')



@app.route('/withdrawnomination')
def withdrawnomination():
    return render_template('withdrawnomination.html')

@app.route('/viewcandidate')
def viewcandidate():
    if request.method == 'GET': 
        conn = mysql.connect() 
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='CHAIRMAN';")
        row=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='VICE CHAIRMAN';")
        data=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='UUC';")
        data1=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='GENERAL SECRETARY';")
        data2=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='FINE ARTS SECRETARY';")
        data3=cursor.fetchall()
        conn.close()
        cursor.close()
        print(row)   
        return render_template('viewcandidate.html',row=row,data=data,data1=data1,data2=data2,data3=data)

@app.route('/viewcandidate_voters')
def viewcandidate_voters():
    if request.method == 'GET': 
        conn = mysql.connect() 
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='CHAIRMAN';")
        row=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='VICE CHAIRMAN';")
        data=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='UUC';")
        data1=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='GENERAL SECRETARY';")
        data2=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='SPORTS CAPTAIN';")
        data4=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='FIRST YEAR REP';")
        data5=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='SECOND YEAR REP';")
        data6=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='THIRD YEAR REP';")
        data6=cursor.fetchall()
        conn.close()
        cursor.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.name,registration.class,registration.gender,nomination.post from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='ASSOCIATION SECRETARY';")
        data6=cursor.fetchall()
        conn.close()
        cursor.close()
        print(row)   
        return render_template('viewcandidate_voters.html',row=row,data=data,data1=data1,data2=data2,data4=data4,data5=data5,data6=data6,data7=data7,data8=data8)


     

@app.route('/addmanifesto',methods=['GET','POST'])
def addmanifesto():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select status,post from nomination where status='Accept' and reg_id="+str(session['rid']))
        row=cursor.fetchone() 
        print(row)
        return render_template('candidateaddmanifesto.html',row=row) 
    if request.method=='POST':
        data=request.form
        conn=mysql.connect()
        cursor=conn.cursor()
        query="update nomination set status='withdraw' where reg_id="+str(session['rid'])
        cursor.execute(query)
        query="update login set type='student' where rid="+str(session['rid'])
        cursor.execute(query)
        conn.commit()
        conn.close() 
        return redirect(url_for('addmanifesto'))            

# @app.route('/withdraw', methods=['GET','POST'])
# def withdraw():
#     if request.method == 'POST':
#         conn =mysql.connect()
#         cursor = conn.cursor()
#         q=" UPDATE nomination SET `post`='{}',`admno`='{}',`mobileno`='{}',`emailid`='{}',`class`='{}',`gender`='{}',`dob`='{}' WHERE `rid`='{}'"
#         query= q.format(request.form.get("name"),
#                         request.form.get("admno"),
#                         request.form.get("mobileno"),
#                         request.form.get("emailid"),
#                         request.form.get("class"),
#                         request.form.get("gender"),
#                         request.form.get("dob"),
#                         request.form.get("rid"))
#         print(query)
#         cursor.execute(query)
#         conn.commit()
#         conn.close()
#         return redirect(url_for('studentlist'))                


# @app.route('/editmanifesto',methods=['GET','POST'])
# def editmanifesto():
#     if request.method == 'GET':
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         cursor.execute("select * from manifesto")
#         row=cursor.fetchone() 
#         print(row)
#         return render_template('editmanifesto.html',row=row)   

# @app.route('/viewnotification')
# def viewnotification():

#     return render_template('viewnotification.html')

# @app.route('/viewresult')
# def viewresult():
#     return render_template('viewresult.html')


@app.route('/registration', methods=['GET','POST'])
def registration():
    if request.method == 'GET':
        return render_template("reg.html")
    if request.method=='POST':
        data = request.form
        # print(data)
        conn = mysql.connect()
        cursor = conn.cursor()
        query = "INSERT INTO registration(admno,name,emailid,mobileno,class,gender,dob) VALUES(%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(query,(data['admsn_no'], data['first_name'], data['email'], data['contact_no'],data['class'],data['gender'],data['dob']))
        conn.commit()
        rid=cursor.lastrowid
        conn.close()
        cursor.close()

        connection = mysql.connect()
        cursor = connection.cursor()
        query = "insert into login(username,password,type,rid) values (%s,%s,%s,%s)"
        cursor.execute(query, (data['email'], data['dob'], 'student',rid))
        connection.commit()
        connection.close()
        cursor.close()


        conne = mysql.connect()
        cursor = conne.cursor()
        query = "insert into voting_status(status,user_id) values (%s,%s)"
        cursor.execute(query, (False,rid))
        conne.commit()
        conne.close()
        cursor.close()
        return render_template('reg.html',msg="Registration successfull") 



# @app.route('/registration', methods=['GET','POST'])
# def registration():
#     if request.method == 'GET':
#         return render_template("registration.html")
#     if request.method=='POST':
#         data = request.form
#         # print(data)
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         query = "INSERT INTO registration(admno,name,emailid,mobileno,class,gender,dob) VALUES(%s,%s,%s,%s,%s,%s,%s)"
#         cursor.execute(query,(data['admsn_no'], data['first_name'], data['email'], data['contact_no'],data['class'],data['gender'],data['dob']))
#         conn.commit()
#         rid=cursor.lastrowid
#         conn.close()
#         cursor.close()
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         query = "insert into login(username,password,type,rid) values (%s,%s,%s,%s)"
#         cursor.execute(query, (data['admsn_no'], data['dob'], 'student',rid))
#         conn.commit()
#         conn.close()
#         cursor.close()
#         return render_template('registration.html',msg="Registration successfull")



@app.route('/admin')
def admin():
    return render_template('admin.html')



@app.route('/postnotifications', methods=['GET','POST'])
def postnotifications():
    if request.method == 'GET':
        return render_template("postnotifications.html")
    if request.method=='POST':
        data = request.form
        # print(data)
        conn = mysql.connect()
        cursor = conn.cursor()
        query = "insert into notifications(notification,date) values (%s,%s)"
        cursor.execute(query, (data['notification'], data['date']))
        conn.commit()
        conn.close()
        cursor.close()
        return render_template('postnotifications.html')
   

@app.route('/validationnomination', methods=['GET','POST'])
def validationnomination(): 
    if request.method=='GET':  
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.*,nomination.* from nomination,registration where registration.rid=nomination.reg_id;")
        row=cursor.fetchall() 
        return render_template('validationnomination.html',rows=row)
    if request.method=='POST':
        data=request.form['status']
        data=data.split()
        print(data)
        conn=mysql.connect()
        cursor=conn.cursor()
        query="update nomination set status='"+str(data[1])+"' where nomination_id="+data[0]
        cursor.execute(query)
        query="update login set type='candidate' where rid="+data[0] 
        cursor.execute(query)
        conn.commit()
        conn.close() 
        return redirect(url_for('validationnomination'))    

        
    
@app.route('/studentlist', methods=['GET','POST'])
def studentlist():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select registration.*,login.* from login,registration where registration.rid=login.rid and login.type!='admin'")
        row=cursor.fetchall() 
        print(row)
        return render_template('studentlist.html',row=row)
    if request.method == 'POST':
        conn = mysql.connect()
        cursor = conn.cursor()
        query="delete from login where rid=%s"
        cursor.execute(query,request.form.get('delete_by_id'))
        conn.commit()
        conn.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        query="delete from registration where rid=%s"
        cursor.execute(query,request.form.get('delete_by_id'))
        conn.commit()
        conn.close()
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select * from registration")
        row=cursor.fetchall() 
        print(row)
        return render_template('studentlist.html',row=row)

@app.route('/edit/<string:id>')  
def editstudent(id):
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select * from registration where rid=%s",id)
        row=cursor.fetchone() 
        print(id)
        cursor.close()
        conn.close()
        # print(session['rid'])
        return render_template('admineditstudentlist.html',row=row)

@app.route('/updatestudent', methods=['GET','POST'])
def updatestudent():
    if request.method == 'POST':
        conn =mysql.connect()
        cursor = conn.cursor()
        q=" UPDATE registration SET `name`='{}',`admno`='{}',`mobileno`='{}',`emailid`='{}',`class`='{}',`gender`='{}',`dob`='{}' WHERE `rid`='{}'"
        query= q.format(request.form.get("name"),
                        request.form.get("admno"),
                        request.form.get("mobileno"),
                        request.form.get("emailid"),
                        request.form.get("class"),
                        request.form.get("gender"),
                        request.form.get("dob"),
                        request.form.get("rid"))
        print(query)
        cursor.execute(query)
        conn.commit()
        conn.close()
        return redirect(url_for('studentlist'))                

# @app.route('/votingcandidatelist', methods=['GET','POST'])
# def votingcandidatelist():
#     if request.method == 'GET':
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         cursor.execute(" select registration.name,nomination.post from nomination,registration where registration.rid=nomination.reg_id and post='general secretary';")
#         row=cursor.fetchall() 
#         print(row)
#         return render_template('votingcandidatelist.html',row=row)
#     if request.method == 'POST':    
#         conn = mysql.connect()
#         cursor = conn.cursor()
#         cursor.execute("select registration.name,nomination.post from nomination,registration where registration.rid=nomination.reg_id and post='vice chairman';")
#         rows=cursor.fetchall() 
#         print(rows)
#         # return render_template('studentlist.html',)
#         return render_template('votingcandidatelist.html',rows=rows)

@app.route('/postcandidatelist')
def postcandidatelist():
    
    return render_template('postcandidatelist.html')

                
    # if request.method=='POST':
    #     data = request.form
    #     # print(data)
    #     conn = mysql.connect()
    #     cursor = conn.cursor()
    #     query = "insert into voting_status(status,user_id) values (%s,%s)"
    #     cursor.execute(query, ('0', session['rid']))
    #     conn.commit()
    #     conn.close()
    #     cursor.close()
    #     return redirect(url_for('castvote'))
  
@app.route('/generateotp')
def generateotp():
    conn = mysql.connect()
    cursor = conn.cursor()
    query="select * from voting_status where user_id="+str(session['rid'])
    cursor.execute(query)
    alr=cursor.fetchone()
    if alr[1]:
        return render_template('castvote.html',msg="You are Already Voted!!!")


    query="select * from otp where rid="+str(session['rid'])
    cursor.execute(query)
    already=cursor.fetchall()
    if len(already)>0:
        return render_template('autherise.html',msg="Autherise with OTP; OTP Send to your registered Email")
        # return render_template('castvote.html',msg="OTP ALREADY GENERATED TO YOUR ACCOUNT")
    else:
        res = ''.join(random.choices(string.ascii_uppercase +
                             string.digits, k = 12))

        print(str(session['rid']))
        rt="select username from login where rid='"+str(session['rid'])+"'"
        cursor.execute(rt)
        user=cursor.fetchone()
        print(user[0])

        msg = Message('Autherisation Key', sender = 'evoteihrdkumbla@gmail.com', recipients = [user[0]])
        msg.body = "hi, Please Autherise your account with the following OTP and keep it secure ::: "+res
        mail.send(msg)
        query = "insert into otp(otp,rid) values (%s,%s)"
        cursor.execute(query, (res, session['rid']))
        conn.commit()
        conn.close()
        cursor.close()
        return render_template('autherise.html',msg="Autherise with OTP")
    return "un-managed-call"

@app.route('/autherise', methods=['POST'])
def autherise():
    if request.method=="POST":
        otp=request.form['otp']
        conn = mysql.connect()
        cursor = conn.cursor()
        query="select * from otp where rid="+str(session['rid'])
        cursor.execute(query)
        already=cursor.fetchone()
        print(already)
        if already:
            if already[1]==otp:
                conn=mysql.connect()
                cursor=conn.cursor()
                query="update voting_status set status='1' where user_id="+str(session['rid']) 
                cursor.execute(query)
                conn.commit()
                conn.close()
                return redirect(url_for('votingcandidatelist'))
                # return render_template('autherise.html',msg="Access Granded for Voting")

            else:
                return render_template('autherise.html',msg="Sorry Invalid OTP")
        else:
            return render_template('autherise.html',msg="Unable to proceed now, Something went wrong")



@app.route('/castvote')
def castvote():
    conn = mysql.connect()
    cursor = conn.cursor()
    # query="select * from otp where rid="+str(session['rid'])
    # cursor.execute(query)
    # already=cursor.fetchall()
    # if len(already)>0:
    #     return render_template('autherise.html',msg="Autherise with OTP")
    # else:
    from_time= datetime(2021, 4, 11, 23, 54, 23, 629225)
    to_time= datetime(2021, 4, 12, 6, 54, 23, 629225)
    current_time = datetime.today()
    time_between = to_time-from_time
    difference = divmod(time_between.seconds, 60)
    print(difference)

    # query="select status from voting_status where user_id="+str(session['rid'])
    # cursor.execute(query)
    # account=cursor.fetchone()
    # cursor.execute(query)
    # if account[0]:
    #     print(account[0])
    #     return render_template('time_over.html')
    # else:


    if current_time > from_time and current_time < to_time:
        return redirect(url_for('vote'))
    else:
        return render_template('time_over.html')


@app.route('/vote') 
def vote():

    return render_template('vote.html')


@app.route('/votingcandidatelist', methods=['GET','POST'])
def votingcandidatelist():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        query="select distinct(post) from posts"
        cursor.execute(query)
        all_post=cursor.fetchall()
        out=[] 
        current_post = '' 
        for item in all_post:
            out.append(item[0])
        session['post']=out
        session['post_identifier']=1
        session['total']=len(out)
        query="select registration.*,nomination.* from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='"+out[0]+"'"
        # query="select * from nomination where status ='Accept' and post='"+out[0]+"'"
        session['post_identifier']=session['post_identifier']+1
        cursor.execute(query)
        all_nominations=cursor.fetchall()  
        print(all_nominations)
        # return jsonify(all_nominations)
        return render_template('votingcandidatelist.html',row=all_nominations, post=out[0])

    if request.method=="POST":
        data = request.form



@app.route('/get-next-post', methods=['GET','POST'])
def test():
    if request.method=="POST":
        regId = request.form['rid']
        conn = mysql.connect()
        cursor = conn.cursor()
        out=session['post']
        print(session['post_identifier'])
        print(session['total'])

        cur = "insert into vote_count (vote,regi_id) values(%s,%s)"
        cursor.execute(cur,('1',regId))
        conn.commit()

        out=session['post']
        
        if session['post_identifier']<session['total']:
            query="select registration.*,nomination.* from nomination,registration where registration.rid=nomination.reg_id and status='Accept' and post='"+out[session['post_identifier']]+"'"
            # query="select * from nomination where status ='Accept' and post='"+out[session['post_identifier']]+"'"
            k=session['post_identifier']
            session['post_identifier']=session['post_identifier']+1
            cursor.execute(query)
            all_nominations=cursor.fetchall()  
            return render_template('votingcandidatelist.html',row=all_nominations, post=out[k])
            # return jsonify(all_nominations)
        else:
            return render_template('voters.html')

        # conn = mysql.connect()
        # cursor = conn.cursor()
    #    
    #  general sec,chair man,chair man,vice chairman,general secretary,UUC,fine arts secretary,sports captain,first year rep,second year rep,third year rep,association secretary,chair man  
        # cursor.execute(query)
        # account=cursor.fetchall()    
        # return render_template('votingcandidatelist.html',row=account)
    

@app.route('/viewmanifesto_voter') 
def viewmanifesto_voter():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        # cursor.execute("select nomination.post,manifesto.manifesto,manifesto.M_id,registration.name from manifesto,nomination,registration where nomination.nomination_id=manifesto.nm_id and registration.rid=nomination.reg_id")
        # select nomination.post,manifesto.manifesto,manifesto.M_id,registration.name from manifesto,nomination,registration where nomination.nomination_id=manifesto.nm_id and registration.rid=nomination.reg_id and registration.rid=26
        cursor.execute("select nomination.post,manifesto.manifesto,manifesto.M_id,registration.name from manifesto,nomination,registration where nomination.nomination_id=manifesto.nm_id and registration.rid=nomination.reg_id and registration.rid="+str(session['rid']))
      
        row=cursor.fetchall() 
        print(row)
        return render_template('voterviewmanifesto.html',row=row)    

@app.route('/admin_viewanifesto') 
def admin_viewanifesto():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select nomination.*,manifesto.*,registration.* from manifesto,nomination,registration where nomination.nomination_id=manifesto.nm_id and registration.rid=nomination.reg_id")
        row=cursor.fetchall() 
        print(row)
        return render_template('admin_viewanifesto.html',row=row)    

@app.route('/viewmanifesto') 
def viewmanifesto():
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select nomination.post,manifesto.manifesto,manifesto.M_id,registration.name from manifesto,nomination,registration where nomination.nomination_id=manifesto.nm_id and registration.rid=nomination.reg_id and registration.rid="+str(session['rid']))
        row=cursor.fetchall() 
        print(row)
        return render_template('viewmanifesto.html',row=row)

@app.route('/editmanifesto/<string:id>',methods=['GET','POST'])
def editmanifesto(id):
    if request.method == 'GET':
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("select * from manifesto where M_id=%s",id)
        row=cursor.fetchone() 
        cursor.close()
        conn.close()
        print(row)
        return render_template('editmanifesto.html',row=row)     

@app.route('/updatemanifesto', methods=['GET','POST'])
def updatemanifesto():
    if request.method == 'POST':
        conn =mysql.connect()
        cursor = conn.cursor()
        q=" UPDATE manifesto SET `manifesto`='{}',`nm_id`='{}' WHERE `M_id`='{}'"
        query= q.format(request.form.get("manifesto"),
                        request.form.get("nm_id"),
                        request.form.get("M_id"))
        print(query)
        cursor.execute(query)
        conn.commit()
        conn.close()
        return redirect(url_for('viewmanifesto'))    

@app.route('/result')
def result():
    if request.method == 'GET':
        to_time= datetime(2021, 4, 10, 6, 54, 23, 629225)
        if datetime.now()<to_time:
            conn = mysql.connect()
            cursor = conn.cursor()


            q1="select r.name,n.post,t.regi_id,count(t.regi_id) as total_vote from vote_count t, nomination n,registration r where t.regi_id=n.reg_id and t.regi_id=r.rid group by t.regi_id order by count(t.regi_id) desc;"
            cursor.execute(q1)
            all_list = cursor.fetchall() 

            q2 = "SELECT distinct(post) FROM evote.nomination"
            cursor.execute(q2)
            distinct_post = cursor.fetchall() 

            q3 = "SELECT * FROM evote.nomination;"
            cursor.execute(q3)
            all_nominations = cursor.fetchall()
            result=[]
            for post in distinct_post:
                qq = "select r.name,n.post,t.regi_id,count(t.regi_id) as total_vote from vote_count t, nomination n,registration r where t.regi_id=n.reg_id and t.regi_id=r.rid and n.post='"+str(post[0])+"' group by t.regi_id order by count(t.regi_id) desc;"
                # q3 = "SELECT * FROM evote.nomination where post='"+str(post[0])+"'"
                cursor.execute(qq)
                all_nominations = cursor.fetchall()
                for nominates in all_nominations:
                    result.append(nominates)


            # return jsonify(result)

            # cursor.execute("select r.name,n.post,t.regi_id,count(t.regi_id) as total_vote from vote_count t, nomination n,registration r where t.regi_id=n.reg_id and t.regi_id=r.rid group by t.regi_id;")
            # row=cursor.fetchall() 
            return render_template('result.html',row=result)
        else:
            return render_template('voteing_on_going.html')


    return render_template('result.html')


# @app.route('/get-post') 
# def viewmanifesto():
#     return render_template('viewmanifesto.html')

@app.route('/posts',methods=['GET','POST']) 
def posts():
    if request.method=="GET":
        return render_template('posts.html')
    if request.method=='POST':
        data = request.form
        # print(data)
        conn = mysql.connect()
        cursor = conn.cursor()
        query = "insert into posts(post,type) values (%s,%s)"
        cursor.execute(query, (data['post'], data['type']))
        conn.commit()
        conn.close()
        cursor.close() 
        print("lol")  
        return render_template('posts.html')

@app.route('/settime') 
def settime():
    return render_template('settime.html')



if (__name__)=='__main__':
    # app.run(debug=True,host="0.0.0.0")
    app.run(debug=True)

    